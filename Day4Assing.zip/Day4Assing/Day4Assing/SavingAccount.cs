﻿using System;

namespace Day4Assing
{
    /// <summary>
    /// creating savingaccount class by implement ibankaccount and its method
    /// </summary>
    class SavingAccount:IBankAccount
    {
        double balance = 2000;

        public void Deposit(double amount)//method of ibankaccount and accept amount for deposit
        {
            balance = balance + amount;
            Console.WriteLine("your balance is {0}",balance);
            Console.WriteLine("your deposit amount is {0}", balance);
        }

        public void Withdraw(double withdrawamount)//method of ibankaccount and accept amount for withdraw
        {
            if (withdrawamount <= balance)
            {
                balance = balance - withdrawamount;
                Console.WriteLine("your balance is {0}", balance);
                Console.WriteLine("your deposit amount is {0}", balance);
            }else
            {
                Console.WriteLine("your balance is low ");
            }
        }
        
    }
}
