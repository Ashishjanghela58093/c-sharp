﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// form for register user
    /// </summary>
    class RegisterUser
    {
        private long _id;
        private string _name;
       private string _emailId;
       private string _dateOfBirth;


        public RegisterUser(long _id, string _name, string _emailId, string _dateOfBirth)//paramterized constructor taking all inputs
        {
            this._id = _id;
            this._name = _name;
            this._emailId = _emailId;
            this._dateOfBirth = _dateOfBirth;

        }


        public override string ToString()//override method of object class 
        {
            return string.Format("id = {0}\n name = {1}\n emilid ={2}\n DateOfBirth = {3}",_id,_name,_emailId, _dateOfBirth);
        }




    }
}
