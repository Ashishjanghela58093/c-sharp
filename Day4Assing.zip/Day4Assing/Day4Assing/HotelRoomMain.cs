﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// main class of hotelroom in this class we take input and create object
    /// </summary>
    class HotelRoomMain
    {
        static void Main(string[] args)
        {
            //taking input from user

            Console.WriteLine("enter number");
            int num = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("enter floor");
            int floo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter room type");
            string typ = Console.ReadLine();
            Console.WriteLine("enter capacity of room");
            int cap = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter time");
            DateTime btime = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("enter room price");
            int rprice = Convert.ToInt32(Console.ReadLine());

            HotelRoom hr = new HotelRoom(num, floo, typ, cap, btime, rprice);//creating object
            // hr.display();
            Console.WriteLine(hr.ToString());//calling ToString Method and print
            Console.ReadLine();

        }
    }
}
