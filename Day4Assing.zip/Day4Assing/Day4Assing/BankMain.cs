﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    class BankMain
    {/// <summary>
    /// main class for savingaccount and currentaccount class 
    /// </summary>
    /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("enter account type");
            string accounttype = Console.ReadLine();//accepting input for account type
            if (accounttype == "saving")
            {
                SavingAccount ac = new SavingAccount();//createing account for saving account
                Console.WriteLine("what you want to do deposit or withdraw");
                string perform = Console.ReadLine();//accepting input form user for  
                if (perform=="deposit")
                {
                    Console.WriteLine("enter amount you want to deposit ");
                    double num =Convert.ToInt16( Console.ReadLine());//amount taken for user
                    ac.Deposit(num);//calling deposit function
                    
                }
                if(perform=="withdraw")
                    {
                    Console.WriteLine("enter amount you want to withdraw from saving account");
                    double num1 = Convert.ToInt16(Console.ReadLine());//amount taken from user
                    ac.Withdraw(num1);
                }
                

            }




            else if (accounttype == "current")
            {
                CurrentAccount ac = new CurrentAccount();//creating object for current account class
                Console.WriteLine("what you want to do deposit or withdraw from saving account");
                string perform = Console.ReadLine();
                if (perform == "deposit")
                {
                    Console.WriteLine("enter amount you want to deposit from current account ");
                    double num = Convert.ToInt16(Console.ReadLine());
                    ac.Deposit(num);//calling deposit function
                }
                if (perform == "withdraw")
                {
                    Console.WriteLine("enter amount you want to withdraw from current account ");
                    double num1 = Convert.ToInt16(Console.ReadLine());
                    ac.Withdraw(num1);//calling withdraw function
                }
            } else{
                Console.WriteLine("enter appropriate details");
            }

            Console.ReadLine();


        }


    }
}
