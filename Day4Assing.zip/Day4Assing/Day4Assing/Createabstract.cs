﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// assingment-> create abstract class with two function
    /// bootup() and shutdown()
    /// </summary>
    abstract class Createabstract
    {
        public abstract void BootUp();//abstract function 

        public void ShutDown()//non abstract function
        {

        }


        



    }
}
