﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// assingment-> create abstract class and 3 classes which will
    /// inherit abstract class
    /// </summary>
    abstract class Computer
    {
        public void Cpu()
        {

        }
        public void mouse()
        {

        }
            

    }
    class SuperComputer:Computer //first class supercomputer inherit couputer
    {


    }

    class MainfraimComputer: Computer // second class MainfraimComputer inherit computer
    {

    }

    class MicroComputers: Computer // third class MicroComputers  inherit computer
    {

    }
}
