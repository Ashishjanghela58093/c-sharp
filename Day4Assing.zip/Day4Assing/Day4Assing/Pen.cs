﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// create sealed class and add two function StartWriting() and  StopWriting()
    /// </summary>
    sealed class Pen
    {
        public void StartWriting()//function of seal class
        {

        }
        public void StopWriting()//function of seal class
        {

        }

    }
}
