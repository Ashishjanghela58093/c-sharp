﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// main class of RegisterUser
    /// </summary>
    class RegisterMain
    {
        static void Main(string[] args)
        {
            //accept input form user
            Console.WriteLine("enter id");
             long num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter name");
            string nam = Convert.ToString(Console.ReadLine());
            Console.WriteLine("enter email");
            string emai = Convert.ToString(Console.ReadLine());
            Console.WriteLine("enter dateofbirth");
            string dob = Convert.ToString(Console.ReadLine());

            RegisterUser ru = new RegisterUser(num, nam, emai, dob);//creatin object  of registeruser class
            Console.WriteLine(ru.ToString());//printing 
            Console.ReadLine();
        }

    }
}
