﻿using System;

namespace Day4Assing
{
    /// <summary>
    /// creating interface
    /// </summary>
    public interface IBankAccount
    {
        void Deposit(double amount);//method 
        void Withdraw(double amount);//method
    }
}