﻿using System;

namespace Day4Assing
{
    



    
    class CurrentAccount:IBankAccount
    {
        double balance = 0;

        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine("your current balance is {0}", balance);
            Console.WriteLine("your current deposit amount is {0}", balance);
        }

        public void Withdraw(double withdrawamount)
        {
            if (withdrawamount <= balance)
            {
                balance = balance - withdrawamount;
                Console.WriteLine("your current balance is {0}", balance);
                Console.WriteLine("your deposit amount is {0}", balance);
            }
            else
            {
                Console.WriteLine("your current balance is low ");
            }
        }
    }
}
