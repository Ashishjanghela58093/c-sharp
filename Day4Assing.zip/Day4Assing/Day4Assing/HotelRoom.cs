﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assing
{
    /// <summary>
    /// program for hotelroom
    /// </summary>
    class HotelRoom
    {
        private int _number;
        private int _floor;
        private string _type;
        private int _capacity;
        private DateTime _bookedTime;
        private double _price;


        public HotelRoom(int _number, int _floor, string _type, int _capacity, DateTime _bookedTime, double _price)//paramterized constructor taking all inputs
        {
            this._number = _number;
            this._floor = _floor;
            this._type = _type;
            this._capacity = _capacity;
            this._bookedTime = _bookedTime;
            this._price = _price;

        }

        //public string display() //it will return data
        //{
        //    //console.writeline("_number={0}\n _floor={1}\n _type={2}\n _capacity={3}\n  _bookedtime={4}\n _price={5}", _number, _floor, _type, _capacity, _bookedtime, _price);

        //    return string.Format("_number={0} _floor={1} _type={2} _capacity={3}  _bookedtime={4}, _price={5}", _number, _floor, _type, _capacity,_bookedTime, _price);

        //    //return convert.tostring("_number={0} _floor={1} _type={2} _capacity={3}  _bookedtime={4}, _price={5}", _number, _floor, _type, _capacity, _bookedtime, _price);
        //}

        public override string ToString()//override method of object class 
        {
            return string.Format("_number={0} _floor={1} _type={2} _capacity={3}  _bookedtime={4}, _price={5}", _number, _floor, _type, _capacity, _bookedTime, _price);
        }


    }
}
