﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    /// <summary>
/// finding sum of array values 
/// </summary>
    class arraysum
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] { 1, 3, 5, 7, 8, 9, 6 };//declaration of array
            int sum = 0;
            foreach(int temp in arr) //foreach loop for accessing values inside array
            {
                sum = sum + temp;
                
            }
            Console.WriteLine(sum);//printing sum
            Console.ReadLine();
        }
    }
}
