﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    /// <summary>
    /// program to display name of day from taking input 1-7 using switch case
    /// </summary>
    class switchassing
    {
        static void Main(string[] args)
        {
            int numofday = Convert.ToInt32(Console.ReadLine());//accepting input from user

            switch (numofday) //using switch cases
            {
                case 1: Console.WriteLine("monday");
                    break;
                case 2:
                    Console.WriteLine("tuesday");
                    break;
                case 3:
                    Console.WriteLine("wednesday");
                    break;
                case 4:
                    Console.WriteLine("thursday");
                    break;
                case 5:
                    Console.WriteLine("friday");
                    break;

                case 6:
                    Console.WriteLine("saturday");
                    break;
                case 7:
                    Console.WriteLine("sunday");
                    break;
                default: Console.WriteLine("invalid");
                    break;
            }
            Console.ReadLine();

        }
        }
}
