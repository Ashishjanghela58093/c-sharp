﻿using System;
;

namespace DAY2
{
    class foreachassin
    {
        /// <summary>
        /// display odd numbers between 1 to 19 using foreach from array
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
            foreach(int tmp in num)
            {
                if(tmp % 2 !=0)
                {
                    Console.WriteLine(tmp);
                }

            }
            Console.ReadLine();
        }

    }
}
