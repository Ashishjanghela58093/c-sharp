﻿using System;


namespace DAY2
{
    /// <summary>
    /// program to decide whether person is major or minor person using Ternary operator
    /// </summary>
    class tenarryage
    {
        static void Main(string[] args)
        {
            int age = Convert.ToInt32(Console.ReadLine());//accepting age from user
            string result = age >= 18 ? "you are major" : "you are minor";//validation using ternary operator
            Console.WriteLine(result);//print
            Console.ReadLine();

        }


        }
}
