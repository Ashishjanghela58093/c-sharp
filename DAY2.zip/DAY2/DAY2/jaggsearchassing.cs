﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    class jaggsearchassing
    {
        /// <summary>
        /// program to search element from jagged array
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int[][] num = new int[2][];//declaration of jagged array
            num[0] = new int[4] { 4, 6, 3, 7 };//insert values in jagged array
            num[1] = new int[3] { 5, 2, 8 };
            int num1 = Convert.ToInt32(Console.ReadLine());
            int count = 0;
            for(int i=0;i<2;i++)//accessing colomn
            {
                foreach(int temp in num[i])//for each accessing row 
                {
                    count++;
                    break;
                }

            }
            if(count==1)//if number is present then count will be 1
            {
                Console.WriteLine("number is present");

            }
            else//number is not present in array then it will execute this
            {
                Console.WriteLine("number is not present");
            }

            Console.ReadLine();

        }


    }
}
