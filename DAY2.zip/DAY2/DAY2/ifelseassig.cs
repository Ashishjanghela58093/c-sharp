﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    /// <summary>
    /// program to decide whether person is major or minor using if-else statement
    /// </summary>
    class ifelseassig
    {
        static void Main(string[] args)//main
        {
            int age = Convert.ToInt32(Console.ReadLine());//accepting age as input from user
            if(age>18)//validation using if else
            {
                Console.WriteLine("you are major");
            }
            else
            {

                Console.WriteLine("you are minor");

            }
            Console.ReadLine();



        }
    }
}
