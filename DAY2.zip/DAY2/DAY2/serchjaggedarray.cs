﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    class serchjaggedarray
    {

        static void Main(string[] args)
        {
            int[][] num = new int[2][];
            num[0] = new int[3] { 1, 3, 4 };
            num[1] = new int[2] { 15, 35 };
            int count = 0;
            int value = Convert.ToInt32(Console.ReadLine());
            for(int i=0;i<2;i++)
            {
                foreach(int temp in num[i])
                {
                     if(temp==value)
                    {

                        count++;
                        break;
                    }
                }
            }
            if(count==1)
            {
                Console.WriteLine("number is present");
            }
            else
            {
                Console.WriteLine("number is not present");
            }
            Console.ReadLine();
        }
    }
}
