﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    class ascciatoi
    {
        /// <summary>
        /// program to print ASCII codes of char from a to i
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            char[,] word = new char[3, 3];//declaration of multidimension array
            word[0, 0] = 'a'; word[0, 1] = 'b'; word[0, 2] = 'c';//inserting values in array
            word[1, 0] = 'd'; word[1, 1] = 'e'; word[1, 2] = 'f';
            word[2, 0] = 'g'; word[2, 1] = 'h'; word[2, 2] = 'i';
            int[,] num = new int[3, 3];
            for(int i=0;i<3;i++)//for loop for accessing colomn
            {
                for (int j = 0; j < 3; j++)//for loop for accessing rows
                {
                    num[i,j]=Convert.ToInt32(word[i, j]);
                }
            }
            int n = 0;
                foreach (int temp in num)//for each loop for printing value in 3*3 form
                
                {
                    Console.Write("\t{0}", temp);
                    n++;
                    if(n==3)
                 {
                    Console.WriteLine();
                    n = 0;
                }
                }
            
            Console.ReadLine();

        }
    }
}
