﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    /// <summary>
    /// program to display numbers in reverse order from 50 to 1 using for Loop construct
    /// </summary>
    class reverse50
    {

        static void Main(string[] args)
        { 
        for(int i=50;i>0;i--)//for loop 
            {
                Console.WriteLine(i);//print value of i

            }
            Console.ReadLine();

        }
    }
}
