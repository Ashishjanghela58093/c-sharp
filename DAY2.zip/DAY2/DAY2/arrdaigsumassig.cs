﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    class arrdaigsumassig
    {
        /// <summary>
        /// finding sum of daigonal values of array
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int[,] num = new int[3,3];//declaration of multidimensional array
            num[0,0]= 10; num[0,1] = 40; num[0,2] =  50;//inserting value in array
            num[1,0] = 60; num[1,1] = 20; num[1,2] = 70;
            num[2,0] = 80; num[2,1] = 90; num[2,2] = 30;

            for(int i=0;i<3;i++)//for loop for accessing values of colomn
            {
                for(int j=0;j<3;j++)//for loop for accessing values of row
                {
                    Console.Write("{0}\t",num[i,j]);
                }
                Console.WriteLine();
            }
           
            int sum = num[0, 0] + num[1, 1] + num[2, 2]; //sum 
            Console.WriteLine("sum of diagonal array is {0} \t",sum);//print
            Console.WriteLine("sum of diagonal array is {0} \t",sum);//print
            Console.ReadLine();
        }

    }
}
