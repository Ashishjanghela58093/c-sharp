﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    /// <summary>
    /// program to make sum of each row for multi dim array 
    /// </summary>
    class sumofarray
    {
        static void Main(string[] args)//main
        {
            int[,] num = new int[3, 3];//declaration of array
            num[0, 0] = 10; num[0, 1] = 50; num[0, 2] = 30;//insert values to arrray
            num[1, 0] = 40; num[1, 1] = 60; num[1, 2] = 10;
            num[2, 0] = 90; num[2, 1] = 20; num[2, 2] = 80;

            int sum1 = num[0, 0] + num[0, 1] + num[0, 2];//sum 
            int sum2 = num[1, 0] + num[1, 1] + num[1, 2];
            int sum3 = num[2, 0] + num[2, 1] + num[2, 2];
            Console.WriteLine("sum of first row is{0} second row{1} third row id {2}",sum1,sum2,sum3);//print
            Console.ReadLine();

        }

    }
}
