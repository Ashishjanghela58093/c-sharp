﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    /// <summary>
    /// print table of given number using for loop
    /// </summary>
    class printtable
    {
        static void Main(string[] args)
        {
            int num = Convert.ToInt32(Console.ReadLine());//take input from user 

            for(int i=1;i<=10;i++)
            {
                int multiple = i * num;
                Console.WriteLine(multiple);//print
            }
            Console.ReadLine();
        }
    }
}
