﻿using System;

namespace DAY2
{
    /// <summary>
    /// program to display odd numbers between 1 to 50 using do while Loop
    /// </summary>
    class dowhileass
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                if(i % 2 != 0)//validation
                {
                    Console.WriteLine(i);
                }
                i++;
            } while (i <= 50);
            Console.ReadLine();
        }
    }
}
