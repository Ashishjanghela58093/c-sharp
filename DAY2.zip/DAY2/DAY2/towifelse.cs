﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY2
{
    class towifelse
    {
        /// <summary>
        /// program to decide grade according to percentage using If-else if-else
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int totalnum = Convert.ToInt32(Console.ReadLine());//accepting value from user

            if (totalnum >= 60) //validation using if-else if-else
            {
                Console.WriteLine("grade A");
            }
            else if (totalnum > 30)
            {
                Console.WriteLine("grade B");
            }
            else
            {
                Console.WriteLine("best of luck");
            }
            Console.ReadLine();
        }
    }
        }
        
