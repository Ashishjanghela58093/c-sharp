﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// structassig main method 
    /// </summary>
    class StructAssigain
    {
        static void Main(string[] args)
        {
            structassig sc = new structassig(123, "ashish", 'm', 8936475);//creating object and passing parameters to constructor
            Console.WriteLine(sc.display());//print
            Console.ReadLine();
        }
    }
}
