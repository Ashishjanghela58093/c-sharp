﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// program to search element from jagged array using Function
    /// </summary>
    class nosearchjaggedarrayass
    {

        public void search()//function
        {
            int[][] num = new int[2][];//declaration of jaggaed array
            num[0] = new int[4] { 4, 6, 3, 7 };//insreting elemuents
            num[1] = new int[3] { 5, 2, 8 };
            int num1 = Convert.ToInt32(Console.ReadLine());//acceptin input from user
            int count = 0;
            for (int i = 0; i < 2; i++)//for loop for accessing colomn
            {
                foreach (int temp in num[i])//foreach loop for accessing row
                {
                    count++;
                    break;
                }

            }
            if (count == 1)//if found number then count =1
            {
                Console.WriteLine("number is present");

            }
            else
            {
                Console.WriteLine("number is not present");
            }
            Console.ReadLine();
        }
        
        




    }
}
