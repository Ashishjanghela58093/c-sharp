﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// program to calculate GST amount using Optional Parameter 
    /// </summary>
    class siusingout
    {

        public int tax(out int amount,int productamount, int gst = 1)//function using out parameter
        {

            amount= productamount * gst / 100;
            int totalamount = gst + amount;
            return amount+productamount;
        }

    }
}
