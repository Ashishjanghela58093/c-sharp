﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    class factmain
    {
        static void Main(string[] args)
        {

            factassing fa = new factassing();//creating object
            fa.getfact();//calling function


        }
    }
}
