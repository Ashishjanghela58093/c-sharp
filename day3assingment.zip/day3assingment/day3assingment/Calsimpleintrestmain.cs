﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// main method of calculate simple intrest
    /// </summary>
    class Calsimpleintrestmain
    {
        static void Main(string[] args)
        {
            Calsimpleintassi cs = new Calsimpleintassi();//create object
            cs.intrest();//function call
        }

    }
}
