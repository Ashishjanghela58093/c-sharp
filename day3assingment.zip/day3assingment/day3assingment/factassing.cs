﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// program to print factorial of given number using Function
    /// </summary>
    class factassing
    {
        public void  getfact()//function
        {
            int num1 = Convert.ToInt32(Console.ReadLine());//accepting input from user
            int fact=1;
            for (int i=1;i<=5;i++)//for loop
            {
                  fact = fact * i;
            }
            Console.Write(fact);//print
            Console.ReadLine();
        }
    }
}
