﻿using System;


namespace day3assingment
{
    /// <summary>
    /// program to calculate Simple Interest using Function
    /// </summary>
    class Calsimpleintassi
    {

        public void intrest()//function 
        {
            int amountinvest =Convert.ToInt32( Console.ReadLine());//accept input fron user
            double rateintrest = amountinvest * 5 / 100;
            double totalamount = amountinvest + rateintrest;
            Console.WriteLine($"your money invest is {amountinvest} your intrest is {rateintrest} and total amount is{totalamount}");//print 
            Console.ReadLine();
        }
        

    }
}
