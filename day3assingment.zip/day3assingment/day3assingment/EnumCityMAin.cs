﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{/// <summary>
/// main method of enumcity
/// </summary>
    class EnumCityMAin
    {
        static void Main(string[] args)
        {
            foreach (string city in Enum.GetNames(typeof(enumcity)))//using foreach loop to access nanes
            {
                Console.WriteLine(city);
            }
            foreach (int code in Enum.GetValues(typeof(enumcity)))//using foreach loop for accessing value
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();

        }
    }
    }

