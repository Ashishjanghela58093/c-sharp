﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// main method of nosearchjaggedarrayass
    /// </summary>
    class JaggedArrayMain
    {
        static void Main(string[] args)
        {
            nosearchjaggedarrayass nja = new nosearchjaggedarrayass();//create object
            nja.search();//calling function
        }
    }
}
