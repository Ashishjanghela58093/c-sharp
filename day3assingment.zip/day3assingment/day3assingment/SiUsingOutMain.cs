﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// main method of siusingout class
    /// </summary>
    class SiUsingOutMain
    {
        static void Main(string[] args)
        {
            siusingout so = new siusingout();//creating object
            int pa = Convert.ToInt32(Console.ReadLine());//accepting input
            int test;
            Console.WriteLine(so.tax(out test, pa));//print
            Console.WriteLine("gst amount is {0}", test);
            Console.ReadLine();

        }
    }
}
