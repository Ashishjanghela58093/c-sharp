﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    /// <summary>
    /// program to maintain City Names and STD Codes using Enum
    /// </summary>
    enum enumcity//declaration of enum
    {
        bhopal=32,pune=45,mumbai=36

    }
}
