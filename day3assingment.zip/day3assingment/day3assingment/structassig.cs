﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3assingment
{
    struct structassig
    {
        int rollno;
        string name;
        char gender;
        int mnumber;

        public structassig(int rollno,string name,char gender, int mnumber)
        {
            this.rollno = rollno;
            this.name = name;
            this.gender = gender;
            this.mnumber = mnumber;
        }


        public string display()
        {
            return string.Format("rollno is {0} name is {1} gender is{2} mnumber is {3}",rollno,name,gender,mnumber);
            
        }
            




    }
}
