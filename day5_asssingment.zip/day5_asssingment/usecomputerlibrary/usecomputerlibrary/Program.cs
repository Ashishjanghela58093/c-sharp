﻿using System;
using CreateLibrary;
using assingcreatelibrary;
namespace usecomputerlibrary
{
   
    class Program
    {
        /// <summary>
        /// using assingcreatelibrary 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            software s = new software("app", "msword", 2019);//creating object
            Console.WriteLine($"{s.display()}"); //calling and print createlibrary method 

            Console.WriteLine($" {s.troubleshoot()}");//calling and print createlibrary method
            

            gst g = new gst(5000);//creating object 
            Console.WriteLine( g.totalamount());//call assingcreatelibrary library method and printing 
            Console.ReadLine();

        }
    }
}
