﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assingcreatelibrary
{
    /// <summary>
    /// create assingcreatelibrary.dll library
    /// </summary>
    public class gst
    {

        int amount;
        int gstper = 5;
        int tamount;
        int gstamount;
        public gst(int amount)//parametrerized constructor accepting amount
        {
            this.amount = amount;
        }

        public string totalamount()//method will return amount 
        {
            gstamount = amount * gstper / 100;
            tamount = amount + gstamount;
            return  $"gst amount {gstamount} total amount ={tamount} your amount ={amount}";
        }

    }
}
