﻿using System;

namespace Day1assesment
{
    class DollerToRupees
    {
        /// <summary>
        /// coverting doller int rupees and viseversa
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            double dollar = 56.5;
            double onedollerinrupees = 81.5;

            double convertdtor =Convert.ToInt32( dollar * onedollerinrupees);//converting dollar into rupees
            Console.WriteLine(convertdtor);//print

            int rupees = 5000;
            double rtod = Convert.ToDouble(rupees/onedollerinrupees);//converting rupees into doller
            Console.WriteLine(rtod);//print

            Console.ReadLine();
        }
        }
}
