﻿using System;

namespace Day1assesment
{
    class AreaOfCircle
    {/// <summary>
    /// finding area of circle
    /// </summary>
    /// <param name="args"></param>
        static void Main(string[] args)
        {
            const double pi = 3.14; //constant value
            int r = 10;
            double area = pi * r * r;
            Console.WriteLine("Area of circle is {0}",area);//print area of circle
            Console.ReadLine();
        }
    }
}
