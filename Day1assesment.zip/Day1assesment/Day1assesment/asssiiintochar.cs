﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1assesment
{
    /// <summary>
    /// finding ascii value
    /// </summary>
    class asssiiintochar
    {
        static void Main(string[] args)
        {

            int ab = 106;
            char num = Convert.ToChar(ab); //conveting integer into ascii value
            Console.WriteLine("ascii value of {0}",num);//print

            char num1 = 'a';
            int ab1 = Convert.ToInt32(num1);//conveting char into ascii value
            Console.WriteLine("number value of {0}", ab1);//print

            Console.ReadLine();
          

        }

        }
}
